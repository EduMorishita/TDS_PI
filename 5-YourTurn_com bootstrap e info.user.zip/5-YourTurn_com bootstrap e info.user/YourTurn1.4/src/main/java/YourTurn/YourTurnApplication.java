package YourTurn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YourTurnApplication {

	public static void main(String[] args) {
		SpringApplication.run(YourTurnApplication.class, args);
	}

}
