package YourTurn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YourTurnApplicationTests {

	@Test
	void contextLoads() {
	}

}
