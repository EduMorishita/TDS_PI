package YourTurn;

public enum AuthenticationProvider {
	LOCAL,GOOGLE
}
